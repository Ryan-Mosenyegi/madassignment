package com.nokito.baufardhome.ui.home

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.*
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.nokito.baufardhome.R
import com.nokito.baufardhome.data.PreferenceManager
import com.nokito.baufardhome.data.SessionManager
import com.nokito.baufardhome.data.model.Listing
import com.nokito.baufardhome.data.repository.AppRepository
import com.nokito.baufardhome.databinding.ActivityHomeBinding
import com.nokito.baufardhome.ui.auth.LoginActivity
import com.nokito.baufardhome.ui.chat.ChatListActivity
import com.nokito.baufardhome.ui.listing.ListingDetailsActivity
import com.nokito.baufardhome.ui.profile.ProfileActivity
import com.nokito.baufardhome.ui.reservations.ReservationsActivity
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

/**
 * The main screen for students. 
 * They can see all the houses, search for stuff, and filter by price.
 */
class HomeActivity : AppCompatActivity() {

    private lateinit var b: ActivityHomeBinding
    private lateinit var adapter: ListingAdapter
    private lateinit var repo: AppRepository
    private var allListings = listOf<Listing>()
    
    private var filterStartTime: Long = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        b = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(b.root)
        repo = AppRepository(this)

        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Students don't add listings, so hide the plus button here.
        b.addListingFab.visibility = android.view.View.GONE

        // Set up the house list with a click listener to see details
        adapter = ListingAdapter(emptyList()) { listing ->
            val intent = Intent(this, ListingDetailsActivity::class.java)
            intent.putExtra("listingId", listing.id)
            startActivity(intent)
        }

        // Two columns look way better than one long list
        b.recyclerView.layoutManager = GridLayoutManager(this, 2)
        b.recyclerView.adapter = adapter

        b.mainFilterBtn.setOnClickListener { openFilterSheet() }
        b.menuBtn.setOnClickListener { showMenu() }
        b.profileBtn.setOnClickListener { startActivity(Intent(this, ProfileActivity::class.java)) }

        loadListings()
    }

    override fun onResume() {
        super.onResume()
        loadListings()
    }

    /**
     * Grabs all the houses from the database and tells the adapter to show them.
     */
    private fun loadListings() {
        lifecycleScope.launch {
            allListings = repo.getListings()
            android.util.Log.d("HomeActivity", "Loaded listings: ${allListings.size}")
            adapter.updateList(allListings)
        }
    }

    /**
     * This opens that cool sliding menu at the bottom for filtering houses.
     */
    private fun openFilterSheet() {
        val dialog = BottomSheetDialog(this)
        val view = LayoutInflater.from(this).inflate(R.layout.filter_bottom_sheet, null)

        val dateBtn = view.findViewById<Button>(R.id.datePickerBtn)
        val seek = view.findViewById<SeekBar>(R.id.priceSeek)
        val priceLabel = view.findViewById<TextView>(R.id.priceLabel)
        val chipGroup = view.findViewById<ChipGroup>(R.id.locationChipGroup)
        val applyBtn = view.findViewById<Button>(R.id.applyFilter)
        val clearFilterBtn = view.findViewById<Button>(R.id.clearFilter)
        val savePrefsBtn = view.findViewById<Button>(R.id.savePrefsBtn)
        val clearPrefsBtn = view.findViewById<Button>(R.id.clearPrefsBtn)

        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        if (filterStartTime > 0) {
            dateBtn.text = sdf.format(Date(filterStartTime))
        }

        dateBtn.setOnClickListener {
            val cal = Calendar.getInstance()
            if (filterStartTime > 0) cal.timeInMillis = filterStartTime
            
            DatePickerDialog(this, { _, y, m, d ->
                val selected = Calendar.getInstance()
                selected.set(y, m, d, 0, 0, 0)
                filterStartTime = selected.timeInMillis
                dateBtn.text = sdf.format(selected.time)
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }

        seek.max = 10000
        seek.progress = 10000
        priceLabel.text = getString(R.string.max_price_format, 10000)

        // Update the price text as they slide the bar
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, f: Boolean) {
                priceLabel.text = getString(R.string.max_price_format, p)
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })

        // Filter the houses based on what they picked
        applyBtn.setOnClickListener {
            val max = seek.progress.toDouble()
            val locs = mutableListOf<String>()
            
            for (i in 0 until chipGroup.childCount) {
                val chip = chipGroup.getChildAt(i) as Chip
                if (chip.isChecked) {
                    locs.add(chip.text.toString())
                }
            }

            lifecycleScope.launch {
                val filtered = repo.filterListings(filterStartTime, max, locs)
                adapter.updateList(filtered)
            }
            dialog.dismiss()
        }

        // Reset everything back to normal
        clearFilterBtn.setOnClickListener {
            filterStartTime = 0L
            seek.progress = 10000
            for (i in 0 until chipGroup.childCount) {
                (chipGroup.getChildAt(i) as Chip).isChecked = false
            }
            loadListings()
            dialog.dismiss()
        }

        // This saves their choices so they get notifications later. Pretty handy.
        savePrefsBtn.setOnClickListener {
            val max = seek.progress.toDouble()
            val locs = mutableSetOf<String>()
            for (i in 0 until chipGroup.childCount) {
                val chip = chipGroup.getChildAt(i) as Chip
                if (chip.isChecked) locs.add(chip.text.toString())
            }
            
            PreferenceManager.savePreferences(this, max, locs, filterStartTime)
            Toast.makeText(this, getString(R.string.prefs_saved), Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        // Wipe the notification settings
        clearPrefsBtn.setOnClickListener {
            PreferenceManager.clearPreferences(this)
            Toast.makeText(this, getString(R.string.prefs_cleared), Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        dialog.setContentView(view)
        dialog.show()
    }

    /**
     * Shows a popup menu for Profile, Logout, etc.
     */
    private fun showMenu() {
        val popup = PopupMenu(this, b.menuBtn)
        popup.menu.add("Profile")
        popup.menu.add("Chats")
        popup.menu.add("My Reservations")
        popup.menu.add("Logout")
        popup.setOnMenuItemClickListener { item ->
            when (item.title) {
                "Profile" -> startActivity(Intent(this, ProfileActivity::class.java))
                "Chats" -> startActivity(Intent(this, ChatListActivity::class.java))
                "My Reservations" -> startActivity(Intent(this, ReservationsActivity::class.java))
                "Logout" -> {
                    SessionManager.logout(this)
                    startActivity(Intent(this, LoginActivity::class.java))
                    finish()
                }
            }
            true
        }
        popup.show()
    }
}
