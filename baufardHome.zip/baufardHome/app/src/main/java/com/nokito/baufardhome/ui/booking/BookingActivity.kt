package com.nokito.baufardhome.ui.booking

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.nokito.baufardhome.databinding.ActivityBookingBinding

class BookingActivity : AppCompatActivity() {

    private lateinit var b: ActivityBookingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        b = ActivityBookingBinding.inflate(layoutInflater)
        setContentView(b.root)

        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val ref = intent.getStringExtra("ref") ?: ""
        b.referenceText.text = "Booking Confirmed ✓\nReference: $ref"
        b.doneBtn.setOnClickListener { finish() }
    }
}
