package com.nokito.baufardhome.ui.listing

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.nokito.baufardhome.R
import com.nokito.baufardhome.data.SessionManager
import com.nokito.baufardhome.data.repository.AppRepository
import com.nokito.baufardhome.databinding.ActivityListingDetailsBinding
import com.nokito.baufardhome.ui.chat.ChatActivity
import com.nokito.baufardhome.ui.reservations.ReservationActivity
import kotlinx.coroutines.launch

/**
 * This is the "View More" page. It shows all the juicy details about a house.
 * Students can see if it's got WiFi and stuff here.
 */
class ListingDetailsActivity : AppCompatActivity() {

    private lateinit var b: ActivityListingDetailsBinding
    private lateinit var repo: AppRepository
    private var listingId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        b = ActivityListingDetailsBinding.inflate(layoutInflater)
        setContentView(b.root)
        repo = AppRepository(this)

        // Make sure the top bar doesn't hide behind the notch
        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        listingId = intent.getIntExtra("listingId", -1)
        b.backBtn.setOnClickListener { finish() }
    }

    /**
     * Re-loading the data every time the page comes back into view.
     * This is useful if the landlord just edited something.
     */
    override fun onResume() {
        super.onResume()
        loadListingDetails()
    }

    private fun loadListingDetails() {
        lifecycleScope.launch {
            val listing = repo.getListing(listingId) ?: return@launch
            val role = SessionManager.getUserRole(this@ListingDetailsActivity)
            val currentUserId = SessionManager.getUserId(this@ListingDetailsActivity)

            // Setting all the text fields with house info
            b.listingTitle.text = listing.title
            b.listingPrice.text = getString(R.string.price_format, listing.price.toInt())
            b.depositAmount.text = getString(R.string.deposit_format, listing.depositAmount.toInt())
            b.listingLocation.text = listing.location
            b.postedBy.text = getString(R.string.posted_by_label, listing.providerName)
            b.listingAmenities.text = listing.amenities.ifEmpty { getString(R.string.none_listed) }
            b.listingDetails.text = listing.description.ifEmpty {
                "${listing.type} in ${listing.location}."
            }

            // Load the image. If there isn't one, just show a placeholder box.
            if (listing.imageUri.isNotEmpty()) {
                Glide.with(this@ListingDetailsActivity)
                    .load(Uri.parse(listing.imageUri))
                    .placeholder(R.drawable.ic_placeholder)
                    .error(R.drawable.ic_placeholder)
                    .centerCrop()
                    .into(b.listingImage)
            } else {
                b.listingImage.setImageResource(R.drawable.ic_placeholder)
            }

            // Students click this to book the place
            b.payBtn.setOnClickListener {
                val i = Intent(this@ListingDetailsActivity, ReservationActivity::class.java)
                i.putExtra("listingId", listing.id)
                startActivity(i)
            }

            // Opens the chat so they can talk to the landlord
            b.contactProviderBtn.setOnClickListener {
                val i = Intent(this@ListingDetailsActivity, ChatActivity::class.java)
                i.putExtra("otherUserId", listing.providerId)
                i.putExtra("otherUserName", listing.providerName)
                startActivity(i)
            }

            // Landlords shouldn't be able to rent their own houses lol
            if (role == "landlord" || !listing.available) {
                b.payBtn.visibility = View.GONE
            } else {
                b.payBtn.visibility = View.VISIBLE
            }

            // If this is the landlord's own house, show the edit and unreserve buttons
            if (currentUserId == listing.providerId) {
                b.contactProviderBtn.visibility = View.GONE
                b.editListingBtn.visibility = View.VISIBLE
                b.editListingBtn.setOnClickListener {
                    val i = Intent(this@ListingDetailsActivity, AddListingActivity::class.java)
                    i.putExtra("listingId", listing.id)
                    startActivity(i)
                }

                if (!listing.available) {
                    b.unreserveBtn.visibility = View.VISIBLE
                    b.unreserveBtn.setOnClickListener {
                        lifecycleScope.launch {
                            val updated = listing.copy(available = true)
                            if (repo.updateListing(updated)) {
                                Toast.makeText(this@ListingDetailsActivity, getString(R.string.listing_unreserved), Toast.LENGTH_SHORT).show()
                                loadListingDetails() // Refresh UI
                            }
                        }
                    }
                } else {
                    b.unreserveBtn.visibility = View.GONE
                }
            } else {
                // Otherwise, show the message button
                b.contactProviderBtn.visibility = View.VISIBLE
                b.editListingBtn.visibility = View.GONE
                b.unreserveBtn.visibility = View.GONE
            }
        }
    }
}
