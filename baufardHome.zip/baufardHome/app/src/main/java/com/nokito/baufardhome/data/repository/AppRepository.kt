package com.nokito.baufardhome.data.repository

import android.content.Context
import com.nokito.baufardhome.data.AppDatabase
import com.nokito.baufardhome.data.PreferenceManager
import com.nokito.baufardhome.data.model.*
import com.nokito.baufardhome.services.NotificationHelper
import java.util.UUID

/**
 * This is like the middleman between the app pages and the database.
 * Instead of talking to the DB directly, all the pages come here and ask for stuff.
 * Keeps things nice and organized.
 */
class AppRepository(private val context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val userDao = db.userDao()
    private val listingDao = db.listingDao()
    private val reservationDao = db.reservationDao()
    private val messageDao = db.messageDao()
    private val cardDao = db.paymentCardDao()

    // ── AUTH STUFF ──────────────────────────────────────────────

    /**
     * Tries to sign up a new user. 
     * Checks if the email is already taken first because that would be bad lol.
     */
    suspend fun register(name: String, email: String, password: String, role: String): Result<User> {
        return try {
            val existing = userDao.getByEmail(email)
            if (existing != null) return Result.failure(Exception("Email already registered"))
            val user = User(name = name, email = email, password = password, role = role)
            val id = userDao.insert(user)
            Result.success(user.copy(id = id.toInt()))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Checks if the email and password match anything in the database.
     */
    suspend fun login(email: String, password: String): Result<User> {
        return try {
            val user = userDao.login(email, password)
                ?: return Result.failure(Exception("Invalid email or password"))
            Result.success(user)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getUser(id: Int): User? = userDao.getById(id)

    suspend fun updateUser(user: User) = userDao.update(user)

    // ── HOUSE LISTINGS ──────────────────────────────────────────

    suspend fun getListings(): List<Listing> = listingDao.getAll()

    suspend fun getListing(id: Int): Listing? = listingDao.getById(id)

    /**
     * Adds a new house. Also checks if any students want a house like this
     * and sends them a notification if they do!
     */
    suspend fun addListing(listing: Listing): Boolean {
        return try {
            listingDao.insert(listing)
            checkPreferencesAndNotify(listing)
            true
        } catch (e: Exception) { false }
    }

    /**
     * This is the "matchmaker" logic. 
     * If a new house matches what a student was looking for, BOOM - notification.
     */
    private fun checkPreferencesAndNotify(listing: Listing) {
        val prefs = PreferenceManager.getPreferences(context) ?: return
        
        val matchesPrice = listing.price <= prefs.maxPrice
        val matchesLocation = prefs.locations.isEmpty() || prefs.locations.contains(listing.location)
        val matchesDate = listing.availableDate >= prefs.startDate
        
        if (matchesPrice && matchesLocation && matchesDate) {
            NotificationHelper.showMatchNotification(context, listing.location)
        }
    }

    suspend fun updateListing(listing: Listing): Boolean {
        return try {
            listingDao.update(listing)
            true
        } catch (e: Exception) { false }
    }

    suspend fun deleteListing(listing: Listing): Boolean {
        return try {
            listingDao.delete(listing)
            true
        } catch (e: Exception) { false }
    }

    suspend fun getLandlordListings(providerId: Int): List<Listing> =
        listingDao.getByProvider(providerId)

    /**
     * This is the filter logic. 
     * It's basically one giant 'when' block to handle all the different ways you can search.
     */
    suspend fun filterListings(startTime: Long, maxPrice: Double, locations: List<String>): List<Listing> {
        return when {
            startTime > 0 && maxPrice > 0 && locations.isNotEmpty() ->
                listingDao.filterByDatePriceAndLocation(startTime, maxPrice, locations)
            startTime > 0 && maxPrice > 0 ->
                listingDao.filterByDateAndPrice(startTime, maxPrice)
            startTime > 0 && locations.isNotEmpty() ->
                listingDao.filterByDateAndLocation(startTime, locations)
            startTime > 0 ->
                listingDao.filterByDate(startTime)
            maxPrice > 0 && locations.isNotEmpty() ->
                listingDao.filterByPriceAndLocation(maxPrice, locations)
            maxPrice > 0 ->
                listingDao.filterByPrice(maxPrice)
            locations.isNotEmpty() ->
                listingDao.filterByLocation(locations)
            else ->
                listingDao.getAll()
        }
    }

    // ── BOOKINGS & RESERVATIONS ──────────────────────────────────────

    /**
     * Makes a new reservation and gives it a random 8-letter code.
     * Also marks the house as "unavailable" so nobody else rents it.
     */
    suspend fun createReservation(listing: Listing, userId: Int): Result<Reservation> {
        return try {
            val ref = UUID.randomUUID().toString().substring(0, 8).uppercase()
            val reservation = Reservation(
                listingId = listing.id,
                listingTitle = listing.title,
                listingLocation = listing.location,
                listingPrice = listing.price,
                userId = userId,
                reference = ref,
                paid = false
            )
            val id = reservationDao.insert(reservation)
            listingDao.markUnavailable(listing.id)
            Result.success(reservation.copy(id = id.toInt()))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun confirmPayment(reservationId: Int): Boolean {
        return try {
            reservationDao.markPaid(reservationId)
            true
        } catch (e: Exception) { false }
    }

    suspend fun getUserReservations(userId: Int): List<Reservation> =
        reservationDao.getByUser(userId)

    // ── CHAT MESSAGES ──────────────────────────────────────────

    suspend fun sendMessage(senderId: Int, receiverId: Int, senderName: String, text: String) {
        messageDao.insert(
            Message(
                senderId = senderId,
                receiverId = receiverId,
                senderName = senderName,
                text = text
            )
        )
    }

    suspend fun getConversation(userId: Int, otherId: Int): List<Message> =
        messageDao.getConversation(userId, otherId)

    suspend fun getRecentChats(userId: Int): List<Message> =
        messageDao.getRecentChats(userId)

    // ── PAYMENT CARDS ─────────────────────────────────────────────

    suspend fun getUserCards(userId: Int): List<PaymentCard> = cardDao.getCardsByUser(userId)

    suspend fun addCard(card: PaymentCard) = cardDao.insert(card)

    suspend fun updateCard(card: PaymentCard) = cardDao.update(card)

    suspend fun deleteCard(card: PaymentCard) = cardDao.delete(card)
}
