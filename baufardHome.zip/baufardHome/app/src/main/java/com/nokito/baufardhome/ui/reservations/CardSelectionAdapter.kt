package com.nokito.baufardhome.ui.reservations

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.nokito.baufardhome.R
import com.nokito.baufardhome.data.model.PaymentCard
import com.nokito.baufardhome.databinding.ItemPaymentCardBinding

class CardSelectionAdapter(
    private var cards: List<PaymentCard>,
    private val onCardSelected: (PaymentCard) -> Unit,
    private val onCardDeleted: (PaymentCard) -> Unit
) : RecyclerView.Adapter<CardSelectionAdapter.ViewHolder>() {

    private var selectedPosition = -1

    inner class ViewHolder(val b: ItemPaymentCardBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val b = ItemPaymentCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(b)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val card = cards[position]
        val context = holder.b.root.context
        holder.b.apply {
            cardNumber.text = context.getString(R.string.card_masked_format, card.cardNumber.takeLast(4))
            cardHolder.text = card.cardHolder
            cardRadio.isChecked = position == selectedPosition

            root.setOnClickListener {
                val oldPos = selectedPosition
                selectedPosition = holder.adapterPosition
                notifyItemChanged(oldPos)
                notifyItemChanged(selectedPosition)
                onCardSelected(card)
            }

            deleteCardBtn.setOnClickListener {
                onCardDeleted(card)
            }
        }
    }

    override fun getItemCount() = cards.size

    fun updateCards(newCards: List<PaymentCard>) {
        cards = newCards
        selectedPosition = if (cards.isNotEmpty()) 0 else -1
        if (selectedPosition != -1) onCardSelected(cards[0])
        notifyDataSetChanged()
    }

    fun getSelectedCard(): PaymentCard? {
        return if (selectedPosition != -1) cards[selectedPosition] else null
    }
}
