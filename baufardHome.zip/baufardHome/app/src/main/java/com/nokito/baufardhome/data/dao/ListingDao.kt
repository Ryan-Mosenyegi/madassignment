package com.nokito.baufardhome.data.dao

import androidx.room.*
import com.nokito.baufardhome.data.model.Listing

@Dao
interface ListingDao {

    @Insert
    suspend fun insert(listing: Listing): Long

    @Update
    suspend fun update(listing: Listing)

    @Delete
    suspend fun delete(listing: Listing)

    @Query("SELECT * FROM listings ORDER BY createdAt DESC")
    suspend fun getAll(): List<Listing>

    @Query("SELECT * FROM listings WHERE id = :id LIMIT 1")
    suspend fun getById(id: Int): Listing?

    @Query("SELECT * FROM listings WHERE providerId = :providerId ORDER BY createdAt DESC")
    suspend fun getByProvider(providerId: Int): List<Listing>

    @Query("SELECT * FROM listings WHERE price <= :maxPrice ORDER BY createdAt DESC")
    suspend fun filterByPrice(maxPrice: Double): List<Listing>

    @Query("SELECT * FROM listings WHERE location IN (:locations) ORDER BY createdAt DESC")
    suspend fun filterByLocation(locations: List<String>): List<Listing>

    @Query("SELECT * FROM listings WHERE price <= :maxPrice AND location IN (:locations) ORDER BY createdAt DESC")
    suspend fun filterByPriceAndLocation(maxPrice: Double, locations: List<String>): List<Listing>

    @Query("SELECT * FROM listings WHERE createdAt >= :startTime ORDER BY createdAt DESC")
    suspend fun filterByDate(startTime: Long): List<Listing>

    @Query("SELECT * FROM listings WHERE createdAt >= :startTime AND price <= :maxPrice ORDER BY createdAt DESC")
    suspend fun filterByDateAndPrice(startTime: Long, maxPrice: Double): List<Listing>

    @Query("SELECT * FROM listings WHERE createdAt >= :startTime AND location IN (:locations) ORDER BY createdAt DESC")
    suspend fun filterByDateAndLocation(startTime: Long, locations: List<String>): List<Listing>

    @Query("SELECT * FROM listings WHERE createdAt >= :startTime AND price <= :maxPrice AND location IN (:locations) ORDER BY createdAt DESC")
    suspend fun filterByDatePriceAndLocation(startTime: Long, maxPrice: Double, locations: List<String>): List<Listing>

    @Query("UPDATE listings SET available = 0 WHERE id = :listingId")
    suspend fun markUnavailable(listingId: Int)
}
