package com.nokito.baufardhome.ui.chat

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.nokito.baufardhome.R
import com.nokito.baufardhome.data.model.Message

class ChatAdapter(
    private var messages: List<Message>,
    private val currentUserId: Int
) : RecyclerView.Adapter<ChatAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val sentBubble: TextView = view.findViewById(R.id.sentBubble)
        val receivedBubble: TextView = view.findViewById(R.id.receivedBubble)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = messages.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val msg = messages[position]
        if (msg.senderId == currentUserId) {
            holder.sentBubble.visibility = View.VISIBLE
            holder.receivedBubble.visibility = View.GONE
            holder.sentBubble.text = msg.text
        } else {
            holder.sentBubble.visibility = View.GONE
            holder.receivedBubble.visibility = View.VISIBLE
            holder.receivedBubble.text = msg.text
        }
    }

    fun updateMessages(newMessages: List<Message>) {
        messages = newMessages
        notifyDataSetChanged()
    }
}