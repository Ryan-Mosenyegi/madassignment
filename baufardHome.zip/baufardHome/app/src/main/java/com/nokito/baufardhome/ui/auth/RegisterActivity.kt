package com.nokito.baufardhome.ui.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.nokito.baufardhome.R
import com.nokito.baufardhome.data.repository.AppRepository
import com.nokito.baufardhome.databinding.ActivityRegisterBinding
import kotlinx.coroutines.launch

/**
 * This is where the magic starts. 
 * People can sign up as either a Student looking for a home, 
 * or a Landlord trying to make some bank lol.
 */
class RegisterActivity : AppCompatActivity() {

    private lateinit var b: ActivityRegisterBinding
    private lateinit var repo: AppRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        b = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(b.root)
        repo = AppRepository(this)

        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        /**
         * When they click Register, we grab all their info.
         * We gotta check if they filled it all out first though.
         */
        b.registerBtn.setOnClickListener {
            val name = b.name.text.toString().trim()
            val email = b.email.text.toString().trim()
            val password = b.password.text.toString().trim()
            // Check which bubble they picked
            val role = if (b.roleLandlord.isChecked) "landlord" else "student"

            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, getString(R.string.fill_all_fields), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Make sure the password isn't super weak
            if (password.length < 4) {
                Toast.makeText(this, getString(R.string.password_too_short), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            b.registerBtn.isEnabled = false
            b.registerBtn.text = getString(R.string.registering)

            lifecycleScope.launch {
                // Try adding them to the database
                val result = repo.register(name, email, password, role)
                if (result.isSuccess) {
                    Toast.makeText(this@RegisterActivity, getString(R.string.account_created), Toast.LENGTH_SHORT).show()
                    // If it worked, send them back to login page
                    startActivity(Intent(this@RegisterActivity, LoginActivity::class.java))
                    finish()
                } else {
                    // Show error if email is already taken or something
                    Toast.makeText(
                        this@RegisterActivity,
                        result.exceptionOrNull()?.message ?: getString(R.string.registration_failed),
                        Toast.LENGTH_SHORT
                    ).show()
                    b.registerBtn.isEnabled = true
                    b.registerBtn.text = getString(R.string.register_btn)
                }
            }
        }

        b.backToLogin.setOnClickListener { finish() }
    }
}
