package com.nokito.baufardhome.ui.reservations

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.nokito.baufardhome.R
import com.nokito.baufardhome.data.SessionManager
import com.nokito.baufardhome.data.model.PaymentCard
import com.nokito.baufardhome.data.repository.AppRepository
import com.nokito.baufardhome.databinding.ActivityPaymentBinding
import com.nokito.baufardhome.databinding.DialogAddCardBinding
import com.nokito.baufardhome.ui.booking.BookingActivity
import kotlinx.coroutines.launch

class PaymentActivity : AppCompatActivity() {

    private lateinit var b: ActivityPaymentBinding
    private lateinit var repo: AppRepository
    private lateinit var cardAdapter: CardSelectionAdapter
    private var selectedCard: PaymentCard? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        b = ActivityPaymentBinding.inflate(layoutInflater)
        setContentView(b.root)
        repo = AppRepository(this)

        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val reservationId = intent.getIntExtra("reservationId", -1)
        val ref = intent.getStringExtra("ref") ?: ""
        val price = intent.getDoubleExtra("price", 0.0)

        setupCardList()

        b.menuBtn.setOnClickListener { finish() }
        b.addCardBtn.setOnClickListener { showAddCardDialog() }

        val priceStr = getString(R.string.price_format, price.toInt())
        b.totalBalance.text = priceStr
        b.finalTotal.text = priceStr

        b.payBtn.setOnClickListener {
            if (selectedCard == null) {
                Toast.makeText(this, getString(R.string.select_card_error), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            b.payBtn.isEnabled = false
            b.payBtn.text = getString(R.string.processing)

            lifecycleScope.launch {
                val success = repo.confirmPayment(reservationId)
                if (success) {
                    val i = Intent(this@PaymentActivity, BookingActivity::class.java)
                    i.putExtra("ref", ref)
                    startActivity(i)
                    finish()
                } else {
                    Toast.makeText(this@PaymentActivity,
                        getString(R.string.payment_failed), Toast.LENGTH_SHORT).show()
                    b.payBtn.isEnabled = true
                    b.payBtn.text = getString(R.string.pay_deposit)
                }
            }
        }
    }

    private fun setupCardList() {
        cardAdapter = CardSelectionAdapter(emptyList(), { card ->
            selectedCard = card
        }, { card ->
            lifecycleScope.launch {
                repo.deleteCard(card)
                loadUserCards()
            }
        })

        b.cardRecyclerView.layoutManager = LinearLayoutManager(this)
        b.cardRecyclerView.adapter = cardAdapter
        loadUserCards()
    }

    private fun loadUserCards() {
        lifecycleScope.launch {
            val userId = SessionManager.getUserId(this@PaymentActivity)
            val cards = repo.getUserCards(userId)
            cardAdapter.updateCards(cards)
            if (cards.isEmpty()) selectedCard = null
        }
    }

    private fun showAddCardDialog() {
        val dialogB = DialogAddCardBinding.inflate(layoutInflater)
        val dialog = AlertDialog.Builder(this)
            .setView(dialogB.root)
            .create()

        dialogB.saveCardBtn.setOnClickListener {
            val number = dialogB.cardNoInput.text.toString().trim()
            val holder = dialogB.cardHolderInput.text.toString().trim()
            val expiry = dialogB.expiryInput.text.toString().trim()
            val cvv = dialogB.cvvInput.text.toString().trim()

            if (number.length < 16 || holder.isEmpty() || expiry.isEmpty() || cvv.length < 3) {
                Toast.makeText(this, getString(R.string.invalid_card_details), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            lifecycleScope.launch {
                val userId = SessionManager.getUserId(this@PaymentActivity)
                repo.addCard(PaymentCard(
                    userId = userId,
                    cardNumber = number,
                    cardHolder = holder,
                    expiryDate = expiry,
                    cvv = cvv
                ))
                loadUserCards()
                dialog.dismiss()
            }
        }

        dialog.show()
    }
}
