package com.nokito.baufardhome.ui.profile

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.nokito.baufardhome.data.SessionManager
import com.nokito.baufardhome.data.repository.AppRepository
import com.nokito.baufardhome.databinding.ActivityProfileBinding
import kotlinx.coroutines.launch

class ProfileActivity : AppCompatActivity() {

    private lateinit var b: ActivityProfileBinding
    private lateinit var repo: AppRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        b = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(b.root)
        repo = AppRepository(this)

        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        b.backBtn.setOnClickListener { finish() }

        lifecycleScope.launch {
            val userId = SessionManager.getUserId(this@ProfileActivity)
            val user = repo.getUser(userId) ?: return@launch
            val nameParts = user.name.split(" ")
            b.firstName.setText(nameParts.firstOrNull() ?: "")
            b.lastName.setText(nameParts.drop(1).joinToString(" "))
            b.phoneNumber.setText(user.phoneNumber)
        }

        b.saveBtn.setOnClickListener {
            val firstName = b.firstName.text.toString().trim()
            val lastName = b.lastName.text.toString().trim()
            val phone = b.phoneNumber.text.toString().trim()
            val fullName = "$firstName $lastName".trim()

            if (fullName.isEmpty()) {
                Toast.makeText(this, "Please enter your name", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            lifecycleScope.launch {
                val userId = SessionManager.getUserId(this@ProfileActivity)
                val user = repo.getUser(userId) ?: return@launch
                repo.updateUser(user.copy(name = fullName, phoneNumber = phone))
                SessionManager.saveUser(this@ProfileActivity, userId, fullName,
                    SessionManager.getUserRole(this@ProfileActivity))
                Toast.makeText(this@ProfileActivity, "Profile updated!", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}