package com.nokito.baufardhome.ui.chat

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.nokito.baufardhome.R
import com.nokito.baufardhome.data.SessionManager
import com.nokito.baufardhome.data.repository.AppRepository
import com.nokito.baufardhome.databinding.ActivityChatBinding
import kotlinx.coroutines.launch

class ChatActivity : AppCompatActivity() {

    private lateinit var b: ActivityChatBinding
    private lateinit var repo: AppRepository
    private lateinit var adapter: ChatAdapter
    private var otherUserId = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        b = ActivityChatBinding.inflate(layoutInflater)
        setContentView(b.root)
        repo = AppRepository(this)

        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        otherUserId = intent.getIntExtra("otherUserId", -1)
        val otherName = intent.getStringExtra("otherUserName") ?: getString(R.string.default_provider_name)

        b.providerName.text = otherName
        b.backBtn.setOnClickListener { finish() }

        val currentUserId = SessionManager.getUserId(this)
        adapter = ChatAdapter(emptyList(), currentUserId)

        val llm = LinearLayoutManager(this)
        llm.stackFromEnd = true
        b.messagesRecycler.layoutManager = llm
        b.messagesRecycler.adapter = adapter

        loadMessages()

        b.sendBtn.setOnClickListener {
            val text = b.messageInput.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener

            b.messageInput.setText("")
            val senderName = SessionManager.getUserName(this)

            lifecycleScope.launch {
                repo.sendMessage(currentUserId, otherUserId, senderName, text)
                loadMessages()
            }
        }
    }

    private fun loadMessages() {
        val currentUserId = SessionManager.getUserId(this)
        lifecycleScope.launch {
            val messages = repo.getConversation(currentUserId, otherUserId)
            adapter.updateMessages(messages)
            if (messages.isNotEmpty()) {
                b.messagesRecycler.scrollToPosition(messages.size - 1)
            }
        }
    }
}