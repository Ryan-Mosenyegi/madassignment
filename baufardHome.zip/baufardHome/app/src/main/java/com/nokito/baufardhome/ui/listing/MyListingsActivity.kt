package com.nokito.baufardhome.ui.listing

import android.content.Intent
import android.os.Bundle
import android.widget.PopupMenu
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.nokito.baufardhome.data.SessionManager
import com.nokito.baufardhome.data.repository.AppRepository
import com.nokito.baufardhome.databinding.ActivityMyListingsBinding
import com.nokito.baufardhome.ui.auth.LoginActivity
import com.nokito.baufardhome.ui.chat.ChatListActivity
import com.nokito.baufardhome.ui.home.ListingAdapter
import com.nokito.baufardhome.ui.profile.ProfileActivity
import com.nokito.baufardhome.ui.reservations.ReservationsActivity
import kotlinx.coroutines.launch

class MyListingsActivity : AppCompatActivity() {

    private lateinit var b: ActivityMyListingsBinding
    private lateinit var repo: AppRepository
    private lateinit var adapter: ListingAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        b = ActivityMyListingsBinding.inflate(layoutInflater)
        setContentView(b.root)
        repo = AppRepository(this)

        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        b.menuBtn.setOnClickListener { showMenu() }
        b.addListingFab.setOnClickListener {
            startActivity(Intent(this, AddListingActivity::class.java))
        }

        adapter = ListingAdapter(emptyList()) { listing ->
            val intent = Intent(this, ListingDetailsActivity::class.java)
            intent.putExtra("listingId", listing.id)
            startActivity(intent)
        }

        b.myListingsRecycler.layoutManager = GridLayoutManager(this, 2)
        b.myListingsRecycler.adapter = adapter

        loadMyListings()
    }

    override fun onResume() {
        super.onResume()
        loadMyListings()
    }

    private fun loadMyListings() {
        lifecycleScope.launch {
            val userId = SessionManager.getUserId(this@MyListingsActivity)
            val myListings = repo.getLandlordListings(userId)
            adapter.updateList(myListings)
        }
    }

    private fun showMenu() {
        val popup = PopupMenu(this, b.menuBtn)
        popup.menu.add("Profile")
        popup.menu.add("Chats")
        popup.menu.add("Logout")
        popup.setOnMenuItemClickListener { item ->
            when (item.title) {
                "Profile" -> startActivity(Intent(this, ProfileActivity::class.java))
                "Chats" -> startActivity(Intent(this, ChatListActivity::class.java))
                "Logout" -> {
                    SessionManager.logout(this)
                    startActivity(Intent(this, LoginActivity::class.java))
                    finish()
                }
            }
            true
        }
        popup.show()
    }
}
