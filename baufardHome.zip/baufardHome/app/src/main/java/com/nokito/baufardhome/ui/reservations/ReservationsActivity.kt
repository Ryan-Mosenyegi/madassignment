package com.nokito.baufardhome.ui.reservations

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.nokito.baufardhome.data.SessionManager
import com.nokito.baufardhome.data.repository.AppRepository
import com.nokito.baufardhome.databinding.ActivityReservationsBinding
import kotlinx.coroutines.launch

class ReservationsActivity : AppCompatActivity() {

    private lateinit var b: ActivityReservationsBinding
    private lateinit var repo: AppRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        b = ActivityReservationsBinding.inflate(layoutInflater)
        setContentView(b.root)
        repo = AppRepository(this)

        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        b.menuBtn.setOnClickListener { finish() }

        val adapter = ReservationListAdapter(emptyList())
        // Use LinearLayoutManager for a list-like view of reservations
        b.recyclerView.layoutManager = LinearLayoutManager(this)
        b.recyclerView.adapter = adapter

        lifecycleScope.launch {
            val userId = SessionManager.getUserId(this@ReservationsActivity)
            val reservations = repo.getUserReservations(userId)
            adapter.updateList(reservations)
        }
    }
}
