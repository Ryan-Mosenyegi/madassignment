package com.nokito.baufardhome.ui.listing

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.nokito.baufardhome.R
import com.nokito.baufardhome.data.SessionManager
import com.nokito.baufardhome.data.model.Listing
import com.nokito.baufardhome.data.repository.AppRepository
import com.nokito.baufardhome.databinding.ActivityAddListingBinding
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

/**
 * This page is for landlords to post new houses or edit old ones.
 * It's got stuff for pictures, prices, and amenities.
 */
class AddListingActivity : AppCompatActivity() {

    private lateinit var b: ActivityAddListingBinding
    private lateinit var repo: AppRepository
    private var selectedImageUri: Uri? = null
    private var selectedAvailableDate: Long = System.currentTimeMillis()
    private var existingListing: Listing? = null

    // This handles picking a photo from the phone's gallery. Pretty standard.
    private val imagePicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            selectedImageUri = it
            b.previewImage.setImageURI(it)
            b.deleteImageBtn.visibility = android.view.View.VISIBLE
            b.addPhotosBtn.visibility = android.view.View.GONE
        }
    }

    /**
     * If the user picks a photo, we copy it to the app's own folder.
     * This way, if they delete the photo from their gallery later, it stays in the app.
     * Smart, right? lol
     */
    private fun saveImageToInternalStorage(uri: Uri): String? {
        return try {
            val inputStream = contentResolver.openInputStream(uri)
            val file = File(filesDir, "listing_${System.currentTimeMillis()}.jpg")
            val outputStream = FileOutputStream(file)
            inputStream?.use { input ->
                outputStream.use { output ->
                    input.copyTo(output)
                }
            }
            Uri.fromFile(file).toString()
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge() // Make it look all modern and full screen
        super.onCreate(savedInstanceState)
        b = ActivityAddListingBinding.inflate(layoutInflater)
        setContentView(b.root)
        repo = AppRepository(this)

        // Fix the padding so the top and bottom bars don't cut off the UI
        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        b.backBtn.setOnClickListener { finish() }
        b.addPhotosBtn.setOnClickListener { imagePicker.launch("image/*") }
        
        // If they click the trash can, clear the image and bring back the plus button
        b.deleteImageBtn.setOnClickListener {
            selectedImageUri = null
            existingListing = existingListing?.copy(imageUri = "")
            b.previewImage.setImageDrawable(null)
            b.deleteImageBtn.visibility = android.view.View.GONE
            b.addPhotosBtn.visibility = android.view.View.VISIBLE
        }

        // Show a nice calendar popup when they click the date field
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        b.availableDate.setText(sdf.format(Date(selectedAvailableDate)))
        b.availableDate.setOnClickListener {
            val cal = Calendar.getInstance()
            DatePickerDialog(this, { _, y, m, d ->
                val selected = Calendar.getInstance()
                selected.set(y, m, d)
                selectedAvailableDate = selected.timeInMillis
                b.availableDate.setText(sdf.format(selected.time))
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }

        // Check if we are editing an old listing or making a new one
        val listingId = intent.getIntExtra("listingId", -1)
        if (listingId != -1) {
            b.deleteBtn.visibility = android.view.View.VISIBLE
            // Delete button with a double check popup so they don't mess up
            b.deleteBtn.setOnClickListener {
                AlertDialog.Builder(this)
                    .setTitle(getString(R.string.delete_listing))
                    .setMessage(getString(R.string.delete_confirm_msg))
                    .setPositiveButton(getString(R.string.delete_label)) { _, _ ->
                        lifecycleScope.launch {
                            existingListing?.let {
                                if (repo.deleteListing(it)) {
                                    Toast.makeText(this@AddListingActivity, getString(R.string.listing_deleted), Toast.LENGTH_SHORT).show()
                                    finish()
                                }
                            }
                        }
                    }
                    .setNegativeButton(getString(R.string.cancel_label), null)
                    .show()
            }

            // Fill in all the existing data so they can change it
            lifecycleScope.launch {
                existingListing = repo.getListing(listingId)
                existingListing?.let {
                    b.title.setText(it.title)
                    b.houseType.setText(it.type)
                    b.location.setText(it.location)
                    b.price.setText(it.price.toString())
                    b.deposit.setText(it.depositAmount.toString())
                    b.amenities.setText(it.amenities)
                    b.description.setText(it.description)
                    selectedAvailableDate = it.availableDate
                    b.availableDate.setText(sdf.format(Date(it.availableDate)))
                    if (it.imageUri.isNotEmpty()) {
                        Glide.with(this@AddListingActivity)
                            .load(Uri.parse(it.imageUri))
                            .placeholder(R.drawable.ic_placeholder)
                            .into(b.previewImage)
                        b.deleteImageBtn.visibility = android.view.View.VISIBLE
                        b.addPhotosBtn.visibility = android.view.View.GONE
                    }
                }
            }
        }

        /**
         * The SAVE button. 
         * It grabs everything from the screen and pushes it to the database.
         */
        b.saveBtn.setOnClickListener {
            val title = b.title.text.toString().trim()
            val type = b.houseType.text.toString().trim()
            val location = b.location.text.toString().trim()
            val priceStr = b.price.text.toString().trim()
            val depositStr = b.deposit.text.toString().trim()
            val amenities = b.amenities.text.toString().trim()
            val description = b.description.text.toString().trim()

            // Basic validation so they don't leave stuff empty
            if (title.isEmpty() || location.isEmpty() || priceStr.isEmpty()) {
                Toast.makeText(this, getString(R.string.fill_required), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            b.saveBtn.isEnabled = false
            b.saveBtn.text = getString(R.string.saving)

            lifecycleScope.launch {
                val userId = SessionManager.getUserId(this@AddListingActivity)
                val userName = SessionManager.getUserName(this@AddListingActivity)

                // Handle the photo stuff
                val finalImageUri = if (selectedImageUri != null) {
                    saveImageToInternalStorage(selectedImageUri!!) ?: selectedImageUri.toString()
                } else {
                    existingListing?.imageUri ?: ""
                }

                // Either update the old one or create a brand new Listing object
                val listing = existingListing?.copy(
                    title = title,
                    price = priceStr.toDoubleOrNull() ?: 0.0,
                    depositAmount = depositStr.toDoubleOrNull() ?: 0.0,
                    location = location,
                    type = type,
                    description = description,
                    amenities = amenities,
                    availableDate = selectedAvailableDate,
                    imageUri = finalImageUri
                ) ?: Listing(
                    title = title,
                    price = priceStr.toDoubleOrNull() ?: 0.0,
                    depositAmount = depositStr.toDoubleOrNull() ?: 0.0,
                    location = location,
                    type = type,
                    description = description,
                    amenities = amenities,
                    available = true,
                    availableDate = selectedAvailableDate,
                    imageUri = finalImageUri,
                    providerId = userId,
                    providerName = userName,
                    createdAt = System.currentTimeMillis()
                )

                // Send it to the repo to handle the actual database save
                val success = if (existingListing != null) repo.updateListing(listing) else repo.addListing(listing)
                if (success) {
                    val msg = if (existingListing != null) "Listing updated!" else getString(R.string.listing_added)
                    Toast.makeText(this@AddListingActivity, msg, Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    Toast.makeText(this@AddListingActivity, getString(R.string.failed_to_save), Toast.LENGTH_SHORT).show()
                    b.saveBtn.isEnabled = true
                    b.saveBtn.text = getString(R.string.save_btn)
                }
            }
        }
    }
}

                val success = if (existingListing != null) repo.updateListing(listing) else repo.addListing(listing)
                if (success) {
                    val msg = if (existingListing != null) "Listing updated!" else getString(R.string.listing_added)
                    Toast.makeText(this@AddListingActivity, msg, Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    Toast.makeText(this@AddListingActivity, getString(R.string.failed_to_save), Toast.LENGTH_SHORT).show()
                    b.saveBtn.isEnabled = true
                    b.saveBtn.text = getString(R.string.save_btn)
                }
            }
        }
    }
}
