package com.nokito.baufardhome.ui.reservations

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.nokito.baufardhome.R
import com.nokito.baufardhome.data.SessionManager
import com.nokito.baufardhome.data.repository.AppRepository
import com.nokito.baufardhome.databinding.ActivityReservationBinding
import kotlinx.coroutines.launch

class ReservationActivity : AppCompatActivity() {

    private lateinit var b: ActivityReservationBinding
    private lateinit var repo: AppRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        b = ActivityReservationBinding.inflate(layoutInflater)
        setContentView(b.root)
        repo = AppRepository(this)

        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val listingId = intent.getIntExtra("listingId", -1)
        b.backBtn.setOnClickListener { finish() }

        lifecycleScope.launch {
            val listing = repo.getListing(listingId) ?: return@launch
            b.listingTitle.text = listing.title
            b.listingLocation.text = listing.location
            b.listingPrice.text = getString(R.string.price_format, listing.price.toInt())

            b.confirmBtn.setOnClickListener {
                b.confirmBtn.isEnabled = false
                val userId = SessionManager.getUserId(this@ReservationActivity)
                
                lifecycleScope.launch {
                    val result = repo.createReservation(listing, userId)
                    if (result.isSuccess) {
                        val reservation = result.getOrNull()!!
                        val i = Intent(this@ReservationActivity, PaymentActivity::class.java)
                        i.putExtra("reservationId", reservation.id)
                        i.putExtra("ref", reservation.reference)
                        i.putExtra("price", reservation.listingPrice)
                        startActivity(i)
                        finish()
                    } else {
                        Toast.makeText(this@ReservationActivity, 
                            "Failed to create reservation", Toast.LENGTH_SHORT).show()
                        b.confirmBtn.isEnabled = true
                    }
                }
            }
        }
    }
}
