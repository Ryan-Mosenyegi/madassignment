package com.nokito.baufardhome.data.dao

import androidx.room.*
import com.nokito.baufardhome.data.model.User

@Dao
interface UserDao {

    @Insert
    suspend fun insert(user: User): Long

    @Query("SELECT * FROM users WHERE email = :email AND password = :password LIMIT 1")
    suspend fun login(email: String, password: String): User?

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getById(id: Int): User?

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getByEmail(email: String): User?

    @Update
    suspend fun update(user: User)

    @Query("SELECT * FROM users")
    suspend fun getAllUsers(): List<User>
}
