package com.nokito.baufardhome.data.dao

import androidx.room.*
import com.nokito.baufardhome.data.model.Reservation

@Dao
interface ReservationDao {

    @Insert
    suspend fun insert(reservation: Reservation): Long

    @Query("SELECT * FROM reservations WHERE userId = :userId")
    suspend fun getByUser(userId: Int): List<Reservation>

    @Query("SELECT * FROM reservations WHERE id = :id LIMIT 1")
    suspend fun getById(id: Int): Reservation?

    @Query("UPDATE reservations SET paid = 1 WHERE id = :id")
    suspend fun markPaid(id: Int)
}
