package com.nokito.baufardhome.data

import android.content.Context

/**
 * This is just a simple way to remember who is logged in.
 * It uses SharedPreferences, which is like a small notebook 
 * the phone keeps even when you close the app.
 */
object SessionManager {
    private const val PREF_NAME = "baufard_session"
    private const val KEY_USER_ID = "user_id"
    private const val KEY_USER_NAME = "user_name"
    private const val KEY_USER_ROLE = "user_role"

    /**
     * Saves the user's ID, Name, and Role so we can customize the app.
     */
    fun saveUser(context: Context, id: Int, name: String, role: String) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putInt(KEY_USER_ID, id)
            .putString(KEY_USER_NAME, name)
            .putString(KEY_USER_ROLE, role)
            .apply()
    }

    /**
     * Gets the ID of whoever is currently using the phone.
     */
    fun getUserId(context: Context): Int {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_USER_ID, -1)
    }

    fun getUserName(context: Context): String {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString(KEY_USER_NAME, "") ?: ""
    }

    /**
     * Checks if they are a "student" or "landlord".
     */
    fun getUserRole(context: Context): String {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString(KEY_USER_ROLE, "student") ?: "student"
    }

    fun isLoggedIn(context: Context): Boolean = getUserId(context) != -1

    /**
     * Wipes the notebook clean. Used when they click "Logout".
     */
    fun logout(context: Context) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().clear().apply()
    }
}
