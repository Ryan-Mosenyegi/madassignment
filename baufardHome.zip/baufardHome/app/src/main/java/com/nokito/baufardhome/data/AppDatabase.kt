package com.nokito.baufardhome.data

import android.content.Context
import android.util.Log
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.nokito.baufardhome.data.dao.*
import com.nokito.baufardhome.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Okay so this is like the brain of the whole app's memory.
 * It's where we keep all the users, houses, and even the chats.
 * Using Room because it's way easier than doing SQL by hand lol.
 */
@Database(
    entities = [User::class, Listing::class, Reservation::class, Message::class, PaymentCard::class],
    version = 11,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    // These are just ways to get to the specific tables
    abstract fun userDao(): UserDao
    abstract fun listingDao(): ListingDao
    abstract fun reservationDao(): ReservationDao
    abstract fun messageDao(): MessageDao
    abstract fun paymentCardDao(): PaymentCardDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * This function basically makes sure we only have ONE database running.
         * Having two would be a mess and probably crash everything.
         */
        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "baufardhome_db"
                )
                    // If we change the version, just wipe everything and start over.
                    // Easier than dealing with migrations when I'm still adding stuff.
                    .fallbackToDestructiveMigration()
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            Log.d("AppDatabase", "onCreate called")
                        }

                        override fun onOpen(db: SupportSQLiteDatabase) {
                            super.onOpen(db)
                            Log.d("AppDatabase", "onOpen called")
                            // Run this in the background so the UI doesn't freeze up
                            CoroutineScope(Dispatchers.IO).launch {
                                val database = getInstance(context)
                                try {
                                    val users = database.userDao().getAllUsers()
                                    // Only add the starter data if the app is empty
                                    if (users.isEmpty()) {
                                        Log.d("AppDatabase", "Seeding data...")
                                        seedData(database)
                                        Log.d("AppDatabase", "Seeding complete")
                                    }
                                } catch (e: Exception) {
                                    Log.e("AppDatabase", "Error checking/seeding: ${e.message}")
                                }
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        /**
         * This massive function just dumps a ton of fake data into the app.
         * Helps for testing so I don't have to register 50 times myself lol.
         */
        private suspend fun seedData(db: AppDatabase) {
            val now = System.currentTimeMillis()
            val day = 86400000L

            // Landlords - adding some cool people to own the houses
            val l1Id = db.userDao().insert(User(name = "Thabo Molefe", email = "thabo.molefe@gmail.com", password = "password123", role = "landlord", createdAt = now - 40 * day)).toInt()
            db.listingDao().insert(Listing(title = "Bachelor Flat in Phakalane", price = 2000.0, depositAmount = 2000.0, location = "Phakalane", type = "Bachelor Flat", description = "Modern unit in Phakalane.", amenities = "WiFi, Water", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_1", providerId = l1Id, providerName = "Thabo Molefe", createdAt = now - 38 * day))
            // ... (rest of the insertions follow the same pattern)
            db.listingDao().insert(Listing(title = "1 Bedroom Unit in Block 3", price = 3500.0, depositAmount = 3500.0, location = "Block 3", type = "1 Bedroom Unit", description = "Cozy 1 bed in Block 3.", amenities = "Water, Electricity", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_2", providerId = l1Id, providerName = "Thabo Molefe", createdAt = now - 36 * day))
            db.listingDao().insert(Listing(title = "2 Bedroom Apartment in Broadhurst", price = 5000.0, depositAmount = 5000.0, location = "Broadhurst", type = "2 Bedroom Apartment", description = "Spacious apartment in Broadhurst.", amenities = "24/7 Security", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_3", providerId = l1Id, providerName = "Thabo Molefe", createdAt = now - 34 * day))
            db.listingDao().insert(Listing(title = "3 Bedroom House in Gaborone West", price = 8500.0, depositAmount = 8500.0, location = "Gaborone West", type = "3 Bedroom House", description = "Large family house.", amenities = "Garden, Garage", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_4", providerId = l1Id, providerName = "Thabo Molefe", createdAt = now - 32 * day))
            db.listingDao().insert(Listing(title = "Studio Apartment in Gaborone North", price = 3000.0, depositAmount = 3000.0, location = "Gaborone North", type = "Studio Apartment", description = "Compact studio.", amenities = "WiFi", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_5", providerId = l1Id, providerName = "Thabo Molefe", createdAt = now - 30 * day))

            val l2Id = db.userDao().insert(User(name = "Lerato Kgosi", email = "lerato.kgosi@yahoo.com", password = "password123", role = "landlord", createdAt = now - 37 * day)).toInt()
            db.listingDao().insert(Listing(title = "1 Bedroom Unit in Phakalane", price = 3650.0, depositAmount = 3650.0, location = "Phakalane", type = "1 Bedroom Unit", description = "Beautiful 1 bed unit.", amenities = "Water, Security", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_6", providerId = l2Id, providerName = "Lerato Kgosi", createdAt = now - 35 * day))
            db.listingDao().insert(Listing(title = "2 Bedroom Apartment in Block 3", price = 5150.0, depositAmount = 5150.0, location = "Block 3", type = "2 Bedroom Apartment", description = "Safe apartment block.", amenities = "WiFi, Parking", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_7", providerId = l2Id, providerName = "Lerato Kgosi", createdAt = now - 33 * day))
            db.listingDao().insert(Listing(title = "3 Bedroom House in Broadhurst", price = 8650.0, depositAmount = 8650.0, location = "Broadhurst", type = "3 Bedroom House", description = "Stunning 3 bed house.", amenities = "Full Amenities", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_8", providerId = l2Id, providerName = "Lerato Kgosi", createdAt = now - 31 * day))
            db.listingDao().insert(Listing(title = "Studio Apartment in Gaborone West", price = 3150.0, depositAmount = 3150.0, location = "Gaborone West", type = "Studio Apartment", description = "Central studio.", amenities = "Water", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_9", providerId = l2Id, providerName = "Lerato Kgosi", createdAt = now - 29 * day))
            db.listingDao().insert(Listing(title = "Bachelor Flat in Gaborone North", price = 2150.0, depositAmount = 2150.0, location = "Gaborone North", type = "Bachelor Flat", description = "Affordable flat.", amenities = "Electricity", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_10", providerId = l2Id, providerName = "Lerato Kgosi", createdAt = now - 27 * day))

            val l3Id = db.userDao().insert(User(name = "Neo Mmereki", email = "neo.mmereki@outlook.com", password = "password123", role = "landlord", createdAt = now - 34 * day)).toInt()
            db.listingDao().insert(Listing(title = "2 Bedroom Apartment in Phakalane", price = 5300.0, depositAmount = 5300.0, location = "Phakalane", type = "2 Bedroom Apartment", description = "Modern apartment.", amenities = "WiFi, Water", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_11", providerId = l3Id, providerName = "Neo Mmereki", createdAt = now - 32 * day))
            db.listingDao().insert(Listing(title = "3 Bedroom House in Block 3", price = 8800.0, depositAmount = 8800.0, location = "Block 3", type = "3 Bedroom House", description = "Secure family home.", amenities = "24/7 Security", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_12", providerId = l3Id, providerName = "Neo Mmereki", createdAt = now - 30 * day))
            db.listingDao().insert(Listing(title = "Studio Apartment in Broadhurst", price = 3300.0, depositAmount = 3300.0, location = "Broadhurst", type = "Studio Apartment", description = "Clean studio room.", amenities = "Water, Electricity", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_13", providerId = l3Id, providerName = "Neo Mmereki", createdAt = now - 28 * day))
            db.listingDao().insert(Listing(title = "Bachelor Flat in Gaborone West", price = 2300.0, depositAmount = 2300.0, location = "Gaborone West", type = "Bachelor Flat", description = "Perfect for students.", amenities = "Water", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_14", providerId = l3Id, providerName = "Neo Mmereki", createdAt = now - 26 * day))
            db.listingDao().insert(Listing(title = "1 Bedroom Unit in Gaborone North", price = 3800.0, depositAmount = 3800.0, location = "Gaborone North", type = "1 Bedroom Unit", description = "Newly renovated unit.", amenities = "WiFi", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_15", providerId = l3Id, providerName = "Neo Mmereki", createdAt = now - 24 * day))

            val l4Id = db.userDao().insert(User(name = "Mpho Segokgo", email = "mpho.segokgo@hotmail.com", password = "password123", role = "landlord", createdAt = now - 31 * day)).toInt()
            db.listingDao().insert(Listing(title = "3 Bedroom House in Phakalane", price = 8950.0, depositAmount = 8950.0, location = "Phakalane", type = "3 Bedroom House", description = "Luxury house.", amenities = "Garden, Pool", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_16", providerId = l4Id, providerName = "Mpho Segokgo", createdAt = now - 29 * day))
            db.listingDao().insert(Listing(title = "Studio Apartment in Block 3", price = 3450.0, depositAmount = 3450.0, location = "Block 3", type = "Studio Apartment", description = "Compact city living.", amenities = "Water, Security", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_17", providerId = l4Id, providerName = "Mpho Segokgo", createdAt = now - 27 * day))
            db.listingDao().insert(Listing(title = "Bachelor Flat in Broadhurst", price = 2450.0, depositAmount = 2450.0, location = "Broadhurst", type = "Bachelor Flat", description = "Simple flat.", amenities = "Electricity", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_18", providerId = l4Id, providerName = "Mpho Segokgo", createdAt = now - 25 * day))
            db.listingDao().insert(Listing(title = "1 Bedroom Unit in Gaborone West", price = 3950.0, depositAmount = 3950.0, location = "Gaborone West", type = "1 Bedroom Unit", description = "Cozy 1 bed.", amenities = "WiFi, Water", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_19", providerId = l4Id, providerName = "Mpho Segokgo", createdAt = now - 23 * day))
            db.listingDao().insert(Listing(title = "2 Bedroom Apartment in Gaborone North", price = 5450.0, depositAmount = 5450.0, location = "Gaborone North", type = "2 Bedroom Apartment", description = "Modern apartment unit.", amenities = "WiFi, Parking", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_20", providerId = l4Id, providerName = "Mpho Segokgo", createdAt = now - 21 * day))

            val l5Id = db.userDao().insert(User(name = "Lesedi Moeti", email = "lesedi.moeti@gmail.com", password = "password123", role = "landlord", createdAt = now - 28 * day)).toInt()
            db.listingDao().insert(Listing(title = "Studio Apartment in Phakalane", price = 3600.0, depositAmount = 3600.0, location = "Phakalane", type = "Studio Apartment", description = "Studio with view.", amenities = "WiFi, Water", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_21", providerId = l5Id, providerName = "Lesedi Moeti", createdAt = now - 26 * day))
            db.listingDao().insert(Listing(title = "Bachelor Flat in Block 3", price = 2600.0, depositAmount = 2600.0, location = "Block 3", type = "Bachelor Flat", description = "Student friendly.", amenities = "Water, Electricity", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_22", providerId = l5Id, providerName = "Lesedi Moeti", createdAt = now - 24 * day))
            db.listingDao().insert(Listing(title = "1 Bedroom Unit in Broadhurst", price = 4100.0, depositAmount = 4100.0, location = "Broadhurst", type = "1 Bedroom Unit", description = "Secure 1 bed unit.", amenities = "Security", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_23", providerId = l5Id, providerName = "Lesedi Moeti", createdAt = now - 22 * day))
            db.listingDao().insert(Listing(title = "2 Bedroom Apartment in Gaborone West", price = 5600.0, depositAmount = 5600.0, location = "Gaborone West", type = "2 Bedroom Apartment", description = "Beautiful apartment.", amenities = "WiFi", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_24", providerId = l5Id, providerName = "Lesedi Moeti", createdAt = now - 20 * day))
            db.listingDao().insert(Listing(title = "3 Bedroom House in Gaborone North", price = 9100.0, depositAmount = 9100.0, location = "Gaborone North", type = "3 Bedroom House", description = "Spacious house.", amenities = "Water, Parking", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_25", providerId = l5Id, providerName = "Lesedi Moeti", createdAt = now - 18 * day))

            val l6Id = db.userDao().insert(User(name = "Kagiso Phiri", email = "kagiso.phiri@yahoo.com", password = "password123", role = "landlord", createdAt = now - 25 * day)).toInt()
            db.listingDao().insert(Listing(title = "Bachelor Flat in Phase 2", price = 2750.0, depositAmount = 2750.0, location = "Phase 2", type = "Bachelor Flat", description = "Safe unit in Phase 2.", amenities = "WiFi", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_26", providerId = l6Id, providerName = "Kagiso Phiri", createdAt = now - 23 * day))
            db.listingDao().insert(Listing(title = "1 Bedroom Unit in Tlokweng", price = 4250.0, depositAmount = 4250.0, location = "Tlokweng", type = "1 Bedroom Unit", description = "Quiet unit.", amenities = "Water", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_27", providerId = l6Id, providerName = "Kagiso Phiri", createdAt = now - 21 * day))
            db.listingDao().insert(Listing(title = "2 Bedroom Apartment in Mogoditshane", price = 5750.0, depositAmount = 5750.0, location = "Mogoditshane", type = "2 Bedroom Apartment", description = "New apartment.", amenities = "Electricity", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_28", providerId = l6Id, providerName = "Kagiso Phiri", createdAt = now - 19 * day))
            db.listingDao().insert(Listing(title = "3 Bedroom House in Extension 12", price = 9250.0, depositAmount = 9250.0, location = "Extension 12", type = "3 Bedroom House", description = "Central location.", amenities = "WiFi, Water", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_29", providerId = l6Id, providerName = "Kagiso Phiri", createdAt = now - 17 * day))
            db.listingDao().insert(Listing(title = "Studio Apartment in Extension 9", price = 3750.0, depositAmount = 3750.0, location = "Extension 9", type = "Studio Apartment", description = "Modern studio.", amenities = "Security", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_30", providerId = l6Id, providerName = "Kagiso Phiri", createdAt = now - 15 * day))

            val l7Id = db.userDao().insert(User(name = "Dineo Mokotedi", email = "dineo.mokotedi@outlook.com", password = "password123", role = "landlord", createdAt = now - 22 * day)).toInt()
            db.listingDao().insert(Listing(title = "1 Bedroom Unit in Phase 2", price = 4400.0, depositAmount = 4400.0, location = "Phase 2", type = "1 Bedroom Unit", description = "Newly built unit.", amenities = "Water, Electricity", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_31", providerId = l7Id, providerName = "Dineo Mokotedi", createdAt = now - 20 * day))
            db.listingDao().insert(Listing(title = "2 Bedroom Apartment in Tlokweng", price = 5900.0, depositAmount = 5900.0, location = "Tlokweng", type = "2 Bedroom Apartment", description = "Safe block.", amenities = "WiFi", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_32", providerId = l7Id, providerName = "Dineo Mokotedi", createdAt = now - 18 * day))
            db.listingDao().insert(Listing(title = "3 Bedroom House in Mogoditshane", price = 9400.0, depositAmount = 9400.0, location = "Mogoditshane", type = "3 Bedroom House", description = "Family oriented.", amenities = "Garden", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_33", providerId = l7Id, providerName = "Dineo Mokotedi", createdAt = now - 16 * day))
            db.listingDao().insert(Listing(title = "Studio Apartment in Extension 12", price = 3900.0, depositAmount = 3900.0, location = "Extension 12", type = "Studio Apartment", description = "Near shops.", amenities = "Water", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_34", providerId = l7Id, providerName = "Dineo Mokotedi", createdAt = now - 14 * day))
            db.listingDao().insert(Listing(title = "Bachelor Flat in Extension 9", price = 2900.0, depositAmount = 2900.0, location = "Extension 9", type = "Bachelor Flat", description = "Clean room.", amenities = "Security", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_35", providerId = l7Id, providerName = "Dineo Mokotedi", createdAt = now - 12 * day))

            val l8Id = db.userDao().insert(User(name = "Onneile Seretse", email = "onneile.seretse@hotmail.com", password = "password123", role = "landlord", createdAt = now - 19 * day)).toInt()
            db.listingDao().insert(Listing(title = "2 Bedroom Apartment in Phase 2", price = 6050.0, depositAmount = 6050.0, location = "Phase 2", type = "2 Bedroom Apartment", description = "Luxury apartment.", amenities = "WiFi, Parking", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_36", providerId = l8Id, providerName = "Onneile Seretse", createdAt = now - 17 * day))
            db.listingDao().insert(Listing(title = "3 Bedroom House in Tlokweng", price = 9550.0, depositAmount = 9550.0, location = "Tlokweng", type = "3 Bedroom House", description = "Spacious property.", amenities = "Garden, Pool", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_37", providerId = l8Id, providerName = "Onneile Seretse", createdAt = now - 15 * day))
            db.listingDao().insert(Listing(title = "Studio Apartment in Mogoditshane", price = 4050.0, depositAmount = 4050.0, location = "Mogoditshane", type = "Studio Apartment", description = "Modern city living.", amenities = "WiFi", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_38", providerId = l8Id, providerName = "Onneile Seretse", createdAt = now - 13 * day))
            db.listingDao().insert(Listing(title = "Bachelor Flat in Extension 12", price = 3050.0, depositAmount = 3050.0, location = "Extension 12", type = "Bachelor Flat", description = "Near transport.", amenities = "Water", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_39", providerId = l8Id, providerName = "Onneile Seretse", createdAt = now - 11 * day))
            db.listingDao().insert(Listing(title = "1 Bedroom Unit in Extension 9", price = 4550.0, depositAmount = 4550.0, location = "Extension 9", type = "1 Bedroom Unit", description = "Well maintained.", amenities = "Electricity", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_40", providerId = l8Id, providerName = "Onneile Seretse", createdAt = now - 9 * day))

            val l9Id = db.userDao().insert(User(name = "Tebogo Kebonang", email = "tebogo.kebonang@gmail.com", password = "password123", role = "landlord", createdAt = now - 16 * day)).toInt()
            db.listingDao().insert(Listing(title = "3 Bedroom House in Phase 2", price = 9700.0, depositAmount = 9700.0, location = "Phase 2", type = "3 Bedroom House", description = "Huge family home.", amenities = "Garage, WiFi", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_41", providerId = l9Id, providerName = "Tebogo Kebonang", createdAt = now - 14 * day))
            db.listingDao().insert(Listing(title = "Studio Apartment in Tlokweng", price = 4200.0, depositAmount = 4200.0, location = "Tlokweng", type = "Studio Apartment", description = "Elegant studio.", amenities = "WiFi, Security", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_42", providerId = l9Id, providerName = "Tebogo Kebonang", createdAt = now - 12 * day))
            db.listingDao().insert(Listing(title = "Bachelor Flat in Mogoditshane", price = 3200.0, depositAmount = 3200.0, location = "Mogoditshane", type = "Bachelor Flat", description = "Student accommodation.", amenities = "Water", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_43", providerId = l9Id, providerName = "Tebogo Kebonang", createdAt = now - 10 * day))
            db.listingDao().insert(Listing(title = "1 Bedroom Unit in Extension 12", price = 4700.0, depositAmount = 4700.0, location = "Extension 12", type = "1 Bedroom Unit", description = "Secure unit.", amenities = "WiFi", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_44", providerId = l9Id, providerName = "Tebogo Kebonang", createdAt = now - 8 * day))
            db.listingDao().insert(Listing(title = "2 Bedroom Apartment in Extension 9", price = 6200.0, depositAmount = 6200.0, location = "Extension 9", type = "2 Bedroom Apartment", description = "Great location.", amenities = "Parking", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_45", providerId = l9Id, providerName = "Tebogo Kebonang", createdAt = now - 6 * day))

            val l10Id = db.userDao().insert(User(name = "Refilwe Marathe", email = "refilwe.marathe@yahoo.com", password = "password123", role = "landlord", createdAt = now - 13 * day)).toInt()
            db.listingDao().insert(Listing(title = "Studio Apartment in Phase 4", price = 4350.0, depositAmount = 4350.0, location = "Phase 4", type = "Studio Apartment", description = "New studio block.", amenities = "WiFi, Water", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_46", providerId = l10Id, providerName = "Refilwe Marathe", createdAt = now - 11 * day))
            db.listingDao().insert(Listing(title = "Bachelor Flat in Tlokweng", price = 3350.0, depositAmount = 3350.0, location = "Tlokweng", type = "Bachelor Flat", description = "Safe property.", amenities = "Water", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_47", providerId = l10Id, providerName = "Refilwe Marathe", createdAt = now - 9 * day))
            db.listingDao().insert(Listing(title = "1 Bedroom Unit in Mogoditshane", price = 4850.0, depositAmount = 4850.0, location = "Mogoditshane", type = "1 Bedroom Unit", description = "Ideal for couples.", amenities = "WiFi", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_48", providerId = l10Id, providerName = "Refilwe Marathe", createdAt = now - 7 * day))
            db.listingDao().insert(Listing(title = "2 Bedroom Apartment in Extension 12", price = 6350.0, depositAmount = 6350.0, location = "Extension 12", type = "2 Bedroom Apartment", description = "Renovated apartment.", amenities = "WiFi, Security", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_49", providerId = l10Id, providerName = "Refilwe Marathe", createdAt = now - 5 * day))
            db.listingDao().insert(Listing(title = "3 Bedroom House in Extension 9", price = 9850.0, depositAmount = 9850.0, location = "Extension 9", type = "3 Bedroom House", description = "Modern house.", amenities = "Full House", imageUri = "android.resource://com.nokito.baufardhome/drawable/house_50", providerId = l10Id, providerName = "Refilwe Marathe", createdAt = now - 3 * day))

            // Students
            db.userDao().insert(User(name = "Kabelo Setshwaelo", email = "kabelo@gmail.com", password = "password123", role = "student", createdAt = now - 60 * day))
            db.userDao().insert(User(name = "Bontle Motsamai", email = "bontle@yahoo.com", password = "password123", role = "student", createdAt = now - 59 * day))
            db.userDao().insert(User(name = "Tshepo Kgosi", email = "tshepo@outlook.com", password = "password123", role = "student", createdAt = now - 58 * day))
            db.userDao().insert(User(name = "Masego Raditladi", email = "masego@hotmail.com", password = "password123", role = "student", createdAt = now - 57 * day))
            db.userDao().insert(User(name = "Modise Sebele", email = "modise@gmail.com", password = "password123", role = "student", createdAt = now - 56 * day))
            db.userDao().insert(User(name = "Lerato Batshogile", email = "lerato.b@yahoo.com", password = "password123", role = "student", createdAt = now - 55 * day))
            db.userDao().insert(User(name = "Katlego Mokone", email = "katlego@outlook.com", password = "password123", role = "student", createdAt = now - 54 * day))
            db.userDao().insert(User(name = "Onkarabile Phiri", email = "onka@hotmail.com", password = "password123", role = "student", createdAt = now - 53 * day))
            db.userDao().insert(User(name = "Palesa Ditau", email = "palesa@gmail.com", password = "password123", role = "student", createdAt = now - 52 * day))
            db.userDao().insert(User(name = "Thabiso Mpofu", email = "thabiso@yahoo.com", password = "password123", role = "student", createdAt = now - 51 * day))
            db.userDao().insert(User(name = "Goitseone Morake", email = "goitse@outlook.com", password = "password123", role = "student", createdAt = now - 50 * day))
            db.userDao().insert(User(name = "Lesedi Kgosiemang", email = "lesedi.k@hotmail.com", password = "password123", role = "student", createdAt = now - 49 * day))
            db.userDao().insert(User(name = "Kealeboga Tau", email = "kealeboga@gmail.com", password = "password123", role = "student", createdAt = now - 48 * day))
            db.userDao().insert(User(name = "Tsholofelo Motshabi", email = "tsholo@yahoo.com", password = "password123", role = "student", createdAt = now - 47 * day))
            db.userDao().insert(User(name = "Gopolang Molosiwa", email = "gopo@outlook.com", password = "password123", role = "student", createdAt = now - 46 * day))
            db.userDao().insert(User(name = "Atlang Gaseitsiwe", email = "atlang@hotmail.com", password = "password123", role = "student", createdAt = now - 45 * day))
            db.userDao().insert(User(name = "Lebogang Seretse", email = "lebo@gmail.com", password = "password123", role = "student", createdAt = now - 44 * day))
            db.userDao().insert(User(name = "Boitshwarelo Kebonang", email = "boit@yahoo.com", password = "password123", role = "student", createdAt = now - 43 * day))
            db.userDao().insert(User(name = "Khumo Magang", email = "khumo@outlook.com", password = "password123", role = "student", createdAt = now - 42 * day))
            db.userDao().insert(User(name = "Phenyo Ramotlhwa", email = "phenyo@hotmail.com", password = "password123", role = "student", createdAt = now - 41 * day))
            db.userDao().insert(User(name = "Kutlo Mokotedi", email = "kutlo@gmail.com", password = "password123", role = "student", createdAt = now - 40 * day))
            db.userDao().insert(User(name = "Tlamelo Gokatweng", email = "tlamelo@yahoo.com", password = "password123", role = "student", createdAt = now - 39 * day))
            db.userDao().insert(User(name = "Oarabile Segokgo", email = "oarabile@outlook.com", password = "password123", role = "student", createdAt = now - 38 * day))
            db.userDao().insert(User(name = "Onneile Mmereki", email = "onneile@hotmail.com", password = "password123", role = "student", createdAt = now - 37 * day))
            db.userDao().insert(User(name = "Lorato Moeti", email = "lorato@gmail.com", password = "password123", role = "student", createdAt = now - 36 * day))
            db.userDao().insert(User(name = "Bame Kgosi", email = "bame@yahoo.com", password = "password123", role = "student", createdAt = now - 35 * day))
            db.userDao().insert(User(name = "Gorata Marathe", email = "gorata@outlook.com", password = "password123", role = "student", createdAt = now - 34 * day))
            db.userDao().insert(User(name = "Wame Molefe", email = "wame@hotmail.com", password = "password123", role = "student", createdAt = now - 33 * day))
            db.userDao().insert(User(name = "Refilwe Kebonang", email = "refilwe.k@gmail.com", password = "password123", role = "student", createdAt = now - 32 * day))
            db.userDao().insert(User(name = "Malebogo Ditau", email = "malebogo@yahoo.com", password = "password123", role = "student", createdAt = now - 31 * day))
            db.userDao().insert(User(name = "Naledi Mpofu", email = "naledi@outlook.com", password = "password123", role = "student", createdAt = now - 30 * day))
            db.userDao().insert(User(name = "Keneilwe Mokone", email = "keneilwe@hotmail.com", password = "password123", role = "student", createdAt = now - 29 * day))
            db.userDao().insert(User(name = "Segolame Batshogile", email = "sego@gmail.com", password = "password123", role = "student", createdAt = now - 28 * day))
            db.userDao().insert(User(name = "One Sebele", email = "one@yahoo.com", password = "password123", role = "student", createdAt = now - 27 * day))
            db.userDao().insert(User(name = "Maipelo Raditladi", email = "maipelo@outlook.com", password = "password123", role = "student", createdAt = now - 26 * day))
            db.userDao().insert(User(name = "Resego Motsamai", email = "resego@hotmail.com", password = "password123", role = "student", createdAt = now - 25 * day))
            db.userDao().insert(User(name = "Oaitse Setshwaelo", email = "oaitse@gmail.com", password = "password123", role = "student", createdAt = now - 24 * day))
            db.userDao().insert(User(name = "Game Morake", email = "game@yahoo.com", password = "password123", role = "student", createdAt = now - 23 * day))
            db.userDao().insert(User(name = "Onalenna Mpofu", email = "onalenna@outlook.com", password = "password123", role = "student", createdAt = now - 22 * day))
            db.userDao().insert(User(name = "Tlotlo Ditau", email = "tlotlo@hotmail.com", password = "password123", role = "student", createdAt = now - 21 * day))
            db.userDao().insert(User(name = "Kgosi Magang", email = "kgosi@gmail.com", password = "password123", role = "student", createdAt = now - 20 * day))
            db.userDao().insert(User(name = "Thato Ramotlhwa", email = "thato@yahoo.com", password = "password123", role = "student", createdAt = now - 15 * day))
            db.userDao().insert(User(name = "Amantle Magang", email = "amantle@outlook.com", password = "password123", role = "student", createdAt = now - 10 * day))
            db.userDao().insert(User(name = "Gosego Sebele", email = "gosego@hotmail.com", password = "password123", role = "student", createdAt = now - 5 * day))
            db.userDao().insert(User(name = "Biotho Motshabi", email = "botho@gmail.com", password = "password123", role = "student", createdAt = now - 3 * day))
            db.userDao().insert(User(name = "Kabo Molosiwa", email = "kabo@yahoo.com", password = "password123", role = "student", createdAt = now - 2 * day))
            db.userDao().insert(User(name = "Neo Molefe", email = "neo.student@outlook.com", password = "password123", role = "student", createdAt = now - 1 * day))
            db.userDao().insert(User(name = "Larona Mpofu", email = "larona@hotmail.com", password = "password123", role = "student", createdAt = now - 12 * 3600000L))
            db.userDao().insert(User(name = "Bake Kgosi", email = "bake@gmail.com", password = "password123", role = "student", createdAt = now - 6 * 3600000L))
            db.userDao().insert(User(name = "Kao Raditladi", email = "kao@yahoo.com", password = "password123", role = "student", createdAt = now - 1 * 3600000L))
        }
    }
}

