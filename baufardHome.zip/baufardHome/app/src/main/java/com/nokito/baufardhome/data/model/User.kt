package com.nokito.baufardhome.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val name: String = "",
    val email: String = "",
    val password: String = "",
    val role: String = "student",
    val phoneNumber: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
