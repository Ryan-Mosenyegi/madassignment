package com.nokito.baufardhome.ui.home

import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.nokito.baufardhome.R
import com.nokito.baufardhome.data.model.Listing
import com.nokito.baufardhome.databinding.ItemListingBinding

/**
 * This class is what takes the house data and turns it into those nice 
 * little boxes you see on the home screen list.
 */
class ListingAdapter(
    private var list: List<Listing>,
    private val onClick: (Listing) -> Unit
) : RecyclerView.Adapter<ListingAdapter.ViewHolder>() {

    // This is basically a container for one house box in the list
    inner class ViewHolder(val b: ItemListingBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // Inflate the XML design for one house item
        val b = ItemListingBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(b)
    }

    override fun getItemCount() = list.size

    /**
     * This is where the actual data gets slapped onto the screen.
     * We set the title, price, location, and the house picture.
     */
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = list[position]
        holder.b.apply {
            val context = root.context
            title.text = item.title
            type.text = context.getString(R.string.type_format, context.getString(R.string.house_type_label), item.type)
            location.text = context.getString(R.string.location_format, context.getString(R.string.location_label), item.location)
            price.text = context.getString(R.string.price_format, item.price.toInt())

            // Color the text differently if it's already rented out
            if (item.available) {
                status.text = context.getString(R.string.unreserved)
                status.setTextColor(context.getColor(R.color.available))
                status.alpha = 0.8f
            } else {
                status.text = context.getString(R.string.reserved_status)
                status.setTextColor(context.getColor(R.color.reserved))
                status.alpha = 1.0f
            }

            // Using Glide to load the house image into the little box.
            // Glide is a lifesaver, handles all the memory stuff for us lol.
            if (item.imageUri.isNotEmpty()) {
                Glide.with(context)
                    .load(Uri.parse(item.imageUri))
                    .placeholder(R.drawable.ic_placeholder)
                    .error(R.drawable.ic_placeholder)
                    .centerCrop()
                    .into(listingImage)
            } else {
                // If there's no photo, just show the grey placeholder icon
                listingImage.setImageResource(R.drawable.ic_placeholder)
            }

            // If they click the box, open the detailed view
            viewBtn.setOnClickListener { onClick(item) }
        }
    }

    /**
     * Call this when the list of houses changes (like after a search).
     */
    fun updateList(newList: List<Listing>) {
        list = newList
        notifyDataSetChanged()
    }
}
