package com.nokito.baufardhome.data.dao

import androidx.room.*
import com.nokito.baufardhome.data.model.Message

@Dao
interface MessageDao {

    @Insert
    suspend fun insert(message: Message)

    @Query("""
        SELECT * FROM messages 
        WHERE (senderId = :userId AND receiverId = :otherId)
        OR (senderId = :otherId AND receiverId = :userId)
        ORDER BY timestamp ASC
    """)
    suspend fun getConversation(userId: Int, otherId: Int): List<Message>

    @Query("""
        SELECT * FROM messages 
        WHERE id IN (
            SELECT MAX(id) FROM messages 
            WHERE senderId = :userId OR receiverId = :userId 
            GROUP BY CASE WHEN senderId = :userId THEN receiverId ELSE senderId END
        )
        ORDER BY timestamp DESC
    """)
    suspend fun getRecentChats(userId: Int): List<Message>
}
