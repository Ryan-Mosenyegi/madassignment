package com.nokito.baufardhome.data.dao

import androidx.room.*
import com.nokito.baufardhome.data.model.PaymentCard

@Dao
interface PaymentCardDao {
    @Insert
    suspend fun insert(card: PaymentCard): Long

    @Update
    suspend fun update(card: PaymentCard)

    @Delete
    suspend fun delete(card: PaymentCard)

    @Query("SELECT * FROM payment_cards WHERE userId = :userId")
    suspend fun getCardsByUser(userId: Int): List<PaymentCard>

    @Query("SELECT * FROM payment_cards WHERE id = :id LIMIT 1")
    suspend fun getById(id: Int): PaymentCard?
}
