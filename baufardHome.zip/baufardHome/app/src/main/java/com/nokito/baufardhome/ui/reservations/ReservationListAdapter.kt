package com.nokito.baufardhome.ui.reservations

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.nokito.baufardhome.R
import com.nokito.baufardhome.data.model.Reservation
import com.nokito.baufardhome.databinding.ItemReservationBinding

class ReservationListAdapter(
    private var list: List<Reservation>
) : RecyclerView.Adapter<ReservationListAdapter.ViewHolder>() {

    inner class ViewHolder(val b: ItemReservationBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val b = ItemReservationBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(b)
    }

    override fun getItemCount() = list.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = list[position]
        val context = holder.b.root.context
        holder.b.apply {
            title.text = item.listingTitle
            location.text = item.listingLocation
            price.text = context.getString(R.string.price_format, item.listingPrice.toInt())
            refText.text = context.getString(R.string.ref_format, item.reference)
            
            if (item.paid) {
                status.text = context.getString(R.string.paid_status)
                status.setTextColor(context.getColor(R.color.available))
                status.setOnClickListener(null)
            } else {
                status.text = context.getString(R.string.pending_payment)
                status.setTextColor(context.getColor(R.color.reserved))
                status.setOnClickListener {
                    val intent = Intent(context, PaymentActivity::class.java).apply {
                        putExtra("reservationId", item.id)
                        putExtra("ref", item.reference)
                        putExtra("price", item.listingPrice)
                    }
                    context.startActivity(intent)
                }
            }
        }
    }

    fun updateList(newList: List<Reservation>) {
        list = newList
        notifyDataSetChanged()
    }
}
