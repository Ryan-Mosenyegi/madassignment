package com.nokito.baufardhome.data

import android.content.Context

object PreferenceManager {
    private const val PREF_NAME = "baufard_prefs"
    private const val KEY_MAX_PRICE = "max_price"
    private const val KEY_LOCATIONS = "locations"
    private const val KEY_START_DATE = "start_date"
    private const val KEY_ENABLED = "prefs_enabled"

    fun savePreferences(context: Context, maxPrice: Double, locations: Set<String>, startDate: Long) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit()
            .putFloat(KEY_MAX_PRICE, maxPrice.toFloat())
            .putStringSet(KEY_LOCATIONS, locations)
            .putLong(KEY_START_DATE, startDate)
            .putBoolean(KEY_ENABLED, true)
            .apply()
    }

    fun getPreferences(context: Context): Prefs? {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(KEY_ENABLED, false)) return null
        
        return Prefs(
            maxPrice = prefs.getFloat(KEY_MAX_PRICE, 0f).toDouble(),
            locations = prefs.getStringSet(KEY_LOCATIONS, emptySet()) ?: emptySet(),
            startDate = prefs.getLong(KEY_START_DATE, 0L)
        )
    }

    fun clearPreferences(context: Context) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit()
            .clear()
            .apply()
    }

    data class Prefs(
        val maxPrice: Double,
        val locations: Set<String>,
        val startDate: Long
    )
}
