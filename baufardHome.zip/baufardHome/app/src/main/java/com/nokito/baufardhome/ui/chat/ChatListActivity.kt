package com.nokito.baufardhome.ui.chat

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.nokito.baufardhome.R
import com.nokito.baufardhome.data.SessionManager
import com.nokito.baufardhome.data.model.Message
import com.nokito.baufardhome.data.repository.AppRepository
import com.nokito.baufardhome.databinding.ActivityChatListBinding
import kotlinx.coroutines.launch

class ChatListActivity : AppCompatActivity() {

    private lateinit var b: ActivityChatListBinding
    private lateinit var repo: AppRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        b = ActivityChatListBinding.inflate(layoutInflater)
        setContentView(b.root)
        repo = AppRepository(this)

        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        b.backBtn.setOnClickListener { finish() }

        val currentUserId = SessionManager.getUserId(this)
        val adapter = ChatListAdapter(emptyList(), currentUserId, repo) { otherId, otherName ->
            val intent = Intent(this, ChatActivity::class.java)
            intent.putExtra("otherUserId", otherId)
            intent.putExtra("otherUserName", otherName)
            startActivity(intent)
        }

        b.chatRecycler.layoutManager = LinearLayoutManager(this)
        b.chatRecycler.adapter = adapter

        lifecycleScope.launch {
            val chats = repo.getRecentChats(currentUserId)
            adapter.updateList(chats)
        }
    }
}

class ChatListAdapter(
    private var list: List<Message>,
    private val currentUserId: Int,
    private val repo: AppRepository,
    private val onClick: (Int, String) -> Unit
) : RecyclerView.Adapter<ChatListAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.userName)
        val lastMsg: TextView = view.findViewById(R.id.lastMessage)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_chat, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = list.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = list[position]
        val otherId = if (item.senderId == currentUserId) item.receiverId else item.senderId
        
        // We need the other user's name. Let's fetch it from repo
        // This is a bit inefficient in onBind, but fine for a small local app.
        // Better would be a Join query in Room.
        (holder.itemView.context as? AppCompatActivity)?.lifecycleScope?.launch {
            val otherUser = repo.getUser(otherId)
            val name = otherUser?.name ?: holder.itemView.context.getString(R.string.default_user_name)
            holder.name.text = name
            holder.itemView.setOnClickListener { onClick(otherId, name) }
        }
        
        holder.lastMsg.text = item.text
    }

    fun updateList(newList: List<Message>) {
        list = newList
        notifyDataSetChanged()
    }
}
