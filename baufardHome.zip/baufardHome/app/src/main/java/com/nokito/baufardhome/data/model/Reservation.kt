package com.nokito.baufardhome.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reservations")
data class Reservation(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val listingId: Int = 0,
    val listingTitle: String = "",
    val listingLocation: String = "",
    val listingPrice: Double = 0.0,
    val userId: Int = 0,
    val reference: String = "",
    val paid: Boolean = false
)

