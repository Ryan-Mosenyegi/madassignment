package com.nokito.baufardhome.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "listings")
data class Listing(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String = "",
    val price: Double = 0.0,
    val depositAmount: Double = 0.0,
    val location: String = "",
    val type: String = "",
    val description: String = "",
    val amenities: String = "",
    val available: Boolean = true,
    val availableDate: Long = System.currentTimeMillis(),
    val imageUri: String = "",
    val providerId: Int = 0,
    val providerName: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
