package com.nokito.baufardhome.utils

import com.nokito.baufardhome.data.model.Listing

object FilterUtils {

    fun filterByPrice(list: List<Listing>, min: Double, max: Double): List<Listing> {
        return list.filter { it.price in min..max }
    }

    fun filterByLocation(list: List<Listing>, location: String): List<Listing> {
        return list.filter { it.location == location }
    }
}