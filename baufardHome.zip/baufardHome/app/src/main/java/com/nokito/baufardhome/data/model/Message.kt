package com.nokito.baufardhome.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class Message(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val senderId: Int = 0,
    val receiverId: Int = 0,
    val senderName: String = "",
    val text: String = "",
    val timestamp: Long = System.currentTimeMillis()
)