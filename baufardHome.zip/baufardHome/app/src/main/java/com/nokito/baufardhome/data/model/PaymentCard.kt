package com.nokito.baufardhome.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "payment_cards")
data class PaymentCard(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val userId: Int,
    val cardNumber: String,
    val cardHolder: String,
    val expiryDate: String,
    val cvv: String
)
