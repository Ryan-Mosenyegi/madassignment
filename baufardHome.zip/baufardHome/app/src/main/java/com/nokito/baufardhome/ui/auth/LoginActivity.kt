package com.nokito.baufardhome.ui.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.nokito.baufardhome.R
import com.nokito.baufardhome.data.SessionManager
import com.nokito.baufardhome.data.repository.AppRepository
import com.nokito.baufardhome.databinding.ActivityLoginBinding
import com.nokito.baufardhome.ui.home.HomeActivity
import com.nokito.baufardhome.ui.listing.MyListingsActivity
import kotlinx.coroutines.launch

/**
 * This is the first thing people see. 
 * They gotta log in here before they can do anything else.
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var b: ActivityLoginBinding
    private lateinit var repo: AppRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        b = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(b.root)
        repo = AppRepository(this)

        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Just to be safe, clear any old sessions when we land on this page
        SessionManager.logout(this)

        b.loginBtn.setOnClickListener {
            val email = b.email.text.toString().trim()
            val password = b.password.text.toString().trim()

            // Don't let them log in if they forgot to type stuff lol
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, getString(R.string.fill_all_fields), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            b.loginBtn.isEnabled = false
            b.loginBtn.text = getString(R.string.logging_in)

            lifecycleScope.launch {
                // Check the database for the user
                val result = repo.login(email, password)
                if (result.isSuccess) {
                    val user = result.getOrNull()!!
                    // Save their info so we remember who they are on other pages
                    SessionManager.saveUser(this@LoginActivity, user.id, user.name, user.role)
                    navigateToHome()
                } else {
                    // Show an error if the password was wrong or something
                    Toast.makeText(
                        this@LoginActivity,
                        result.exceptionOrNull()?.message ?: getString(R.string.login_failed),
                        Toast.LENGTH_SHORT
                    ).show()
                    b.loginBtn.isEnabled = true
                    b.loginBtn.text = getString(R.string.login_btn)
                }
            }
        }

        // Send them to the sign-up page if they don't have an account
        b.registerLink.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    /**
     * Decisions, decisions... 
     * Students go to the house feed, Landlords go to their own house list.
     */
    private fun navigateToHome() {
        val role = SessionManager.getUserRole(this)
        val intent = if (role == "landlord") {
            Intent(this, MyListingsActivity::class.java)
        } else {
            Intent(this, HomeActivity::class.java)
        }
        startActivity(intent)
        finish()
    }
}
